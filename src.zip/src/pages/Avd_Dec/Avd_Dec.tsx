import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const Avd_Dec: React.FC = () => {
  const [chartData, setChartData] = useState<
    { time: string; advances: number; declines: number }[]
  >([]);

  const fetchAdvDecData = async () => {
    try {
      const res = await fetch("http://localhost:8000/api/advdec");
      const data = await res.json();
      setChartData(data);
    } catch (error) {
      console.error("Failed to fetch advance/decline data", error);
    }
  };

  useEffect(() => {
    fetchAdvDecData(); // initial fetch

    const interval = setInterval(fetchAdvDecData, 60000); // fetch every 1 min
    return () => clearInterval(interval);
  }, []);

  // Calculate latest advances and declines from last data point
  const latest = chartData.length ? chartData[chartData.length - 1] : null;

  return (
    <motion.div
      className="w-full max-w-4xl h-[290px] bg-gray-900 rounded-xl shadow-lg p-6"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <h2 className="text-2xl font-semibold text-center mb-2 text-white">Adv/Dec</h2>
      <div className="flex justify-center gap-6 text-white mb-4 text-lg">
        <div>
          Advances: <span className="text-green-400 font-semibold">{latest?.advances ?? 0}</span>
        </div>
        <div>
          Declines: <span className="text-red-400 font-semibold">{latest?.declines ?? 0}</span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ right: 20, left: -20 }}>
          <XAxis dataKey="time" stroke="#9CA3AF" tick={{ fill: "#9CA3AF" }} />
          <YAxis stroke="#9CA3AF" tick={{ fill: "#9CA3AF" }} />
          <Tooltip
            contentStyle={{ backgroundColor: "#111827", borderColor: "#374151", borderRadius: "0.5rem" }}
            itemStyle={{ color: "#FFFFFF" }}
          />
          <Legend verticalAlign="bottom" wrapperStyle={{ color: "#D1D5DB" }} />
          <Line type="monotone" dataKey="advances" stroke="#10B981" strokeWidth={2.5} dot={false} />
          <Line type="monotone" dataKey="declines" stroke="#EF4444" strokeWidth={2.5} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </motion.div>
  );
};

export default Avd_Dec;